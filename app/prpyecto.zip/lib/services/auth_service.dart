import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

class AuthService extends ChangeNotifier {
  final String _baseUrl = 'localhost:7106';
  final storage = const FlutterSecureStorage();

  Future<String?> login(String email, String password) async {
    final Map<String, dynamic> authData = {
      "username": email,
      "password": password,
    };

    final jsonData = json.encode(authData);

    final url = Uri.https(_baseUrl, '/api/Account/Login');

    try {
      final response = await http.post(
        url,
        body: jsonData,
        headers: {
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        final decodedResponse =
            json.decode(response.body) as Map<String, dynamic>;

        if (decodedResponse.containsKey('jwtToken')) {
          final token = decodedResponse['jwtToken'] as String;
          await storage.write(key: 'token', value: token);
          return null;
        } else if (decodedResponse.containsKey('message')) {
          return decodedResponse['message'] as String;
        }
      } else if (response.statusCode == 400) {
        return 'Credenciales inválidas. Por favor, verifica tu correo y contraseña.';
      } else if (response.statusCode >= 401 && response.statusCode < 600) {
        return response.reasonPhrase ?? 'Error en la solicitud';
      } else {
        return 'Error en la solicitud';
      }
    } catch (error) {
      return 'Error: $error';
    }

    return 'Error desconocido';
  }

  Future<void> logout() async {
    await storage.delete(key: 'token');
  }

  Future<String> readToken() async {
    return await storage.read(key: 'token') ?? '';
  }
}
